import { Banknote, Boxes, CircleDollarSign, LoaderCircle, PackagePlus, Store, WalletCards } from "lucide-react";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { Navigate } from "react-router-dom";
import CashSaleDialog from "../components/marketplace/CashSaleDialog";
import ListingEditDialog from "../components/marketplace/ListingEditDialog";
import ListingEditor from "../components/marketplace/ListingEditor";
import { useAuth } from "../context/AuthContext";
import {
  createSellerProfile,
  formatMoney,
  getSellerListings,
  getSellerProfile,
  getSellerSales,
  updateListing,
  type MarketplaceListing,
  type SellerProfile,
  type SellerSale,
} from "../services/marketplaceApi";

export default function SellerDashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [listings, setListings] = useState<MarketplaceListing[]>([]);
  const [sales, setSales] = useState<SellerSale[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cashListing, setCashListing] = useState<MarketplaceListing | null>(null);
  const [editListing, setEditListing] = useState<MarketplaceListing | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const profile = await getSellerProfile();
      setSeller(profile);
      if (profile && profile.status !== "suspended") {
        const [sellerListings, sellerSales] = await Promise.all([getSellerListings(), getSellerSales()]);
        setListings(sellerListings);
        setSales(sellerSales);
      } else {
        setListings([]);
        setSales([]);
      }
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Unable to load seller dashboard.");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { void load(); }, [load]);

  const totalSales = useMemo(() => sales.reduce((sum, sale) => sum + sale.subtotal_cents, 0), [sales]);
  const unitsAvailable = useMemo(() => listings.reduce((sum, listing) => sum + listing.quantity, 0), [listings]);

  if (authLoading) return <main className="store-shell seller-page"><div className="prototype-note wide-note"><LoaderCircle className="spin" size={18} /> Checking your account...</div></main>;
  if (!user) return <Navigate to="/login?return=/seller" replace />;
  if (loading) return <main className="store-shell seller-page"><div className="prototype-note wide-note"><LoaderCircle className="spin" size={18} /> Loading seller dashboard...</div></main>;
  if (error) return <main className="store-shell seller-page"><div className="checkout-error">{error}</div></main>;
  if (!seller) return <SellerOnboarding onCreated={profile => { setSeller(profile); setListings([]); setSales([]); }} />;

  async function setStatus(listing: MarketplaceListing, status: "draft" | "published" | "archived") {
    try {
      setError(null);
      const updated = await updateListing(listing.id, { status });
      setListings(current => current.map(item => item.id === updated.id ? updated : item));
    } catch (statusError) {
      setError(statusError instanceof Error ? statusError.message : "Unable to update listing.");
    }
  }

  return (
    <main className="store-shell seller-page">
      <div className="seller-page-heading"><div><span className="eyebrow dark">SELLER CENTER</span><h1>{seller.display_name}</h1><p>Manage listings, inventory, cash sales, and payouts.</p></div><span className={`seller-status ${seller.status}`}>{seller.status}</span></div>

      {seller.status === "pending" && <div className="seller-alert pending"><strong>Approval pending.</strong><span>You can create listings and track in-person inventory now. OneTime Labs approval unlocks public publishing.</span></div>}
      {seller.status === "suspended" && <div className="seller-alert suspended"><strong>Seller account suspended.</strong><span>Listings and seller actions are temporarily unavailable.</span></div>}

      <section className="seller-summary-grid">
        <article><Boxes size={20} /><div><strong>{listings.length}</strong><span>Listings</span></div></article>
        <article><PackagePlus size={20} /><div><strong>{unitsAvailable}</strong><span>Units available</span></div></article>
        <article><CircleDollarSign size={20} /><div><strong>{formatMoney(totalSales)}</strong><span>Recorded sales</span></div></article>
        <article><WalletCards size={20} /><div><strong>{seller.stripe_onboarding_complete ? "Connected" : "Not connected"}</strong><span>Stripe payouts</span></div></article>
      </section>

      <section className="seller-stripe-card"><div><WalletCards size={21} /><div><strong>Seller payments</strong><span>{seller.stripe_onboarding_complete ? "Stripe seller account connected." : "Stripe Connect is the next setup step. Your seller record is ready for it."}</span></div></div><button className="button secondary" disabled>{seller.stripe_onboarding_complete ? "Manage Stripe" : "Connect Stripe next"}</button></section>

      <ListingEditor user={user} seller={seller} onCreated={listing => setListings(current => [listing, ...current])} />

      <section className="seller-section">
        <div className="seller-section-heading"><div><span className="eyebrow dark">INVENTORY</span><h2>Your listings</h2></div></div>
        {listings.length === 0 ? <div className="marketplace-empty compact"><p>No products yet. Add the first RAM listing above.</p></div> : <div className="seller-listing-table">{listings.map(listing => <article key={listing.id} className="seller-listing-row">
          <div className="seller-listing-thumb">{listing.image_urls?.[0] ? <img src={listing.image_urls[0]} alt="" /> : <Boxes size={22} />}</div>
          <div className="seller-listing-info"><strong>{listing.title}</strong><span>{listing.condition} · {listing.quantity} available · {formatMoney(listing.price_cents)}</span></div>
          <span className={`listing-status ${listing.status}`}>{listing.status.replace("_", " ")}</span>
          <div className="seller-listing-actions">
            <button className="button secondary small" onClick={() => setEditListing(listing)}>Edit</button>
            {listing.cash_sale_allowed && listing.quantity > 0 && <button className="button cash-button small" onClick={() => setCashListing(listing)}><Banknote size={15} /> Sold - Cash</button>}
            {seller.status === "approved" && listing.status !== "published" && listing.quantity > 0 && <button className="button secondary small" onClick={() => void setStatus(listing, "published")}>Publish</button>}
            {listing.status === "published" && <button className="button secondary small" onClick={() => void setStatus(listing, "draft")}>Unpublish</button>}
            {listing.status !== "archived" && <button className="text-action" onClick={() => void setStatus(listing, "archived")}>Archive</button>}
          </div>
        </article>)}</div>}
      </section>

      <section className="seller-section">
        <div className="seller-section-heading"><div><span className="eyebrow dark">SALES</span><h2>Recent sales</h2></div></div>
        {sales.length === 0 ? <div className="marketplace-empty compact"><p>No sales recorded yet.</p></div> : <div className="seller-sales-table">{sales.map(sale => <article key={sale.id}><div><strong>{sale.store_listings?.title || "Manual sale"}</strong><span>{new Date(sale.sold_at).toLocaleString()}</span></div><span className={`sale-channel ${sale.channel}`}>{sale.channel}</span><strong>{sale.quantity} × {formatMoney(sale.unit_price_cents)}</strong><strong>{formatMoney(sale.subtotal_cents)}</strong><span>{sale.buyer_name || sale.buyer_contact || sale.cash_note || "—"}</span></article>)}</div>}
      </section>

      {editListing && <ListingEditDialog listing={editListing} user={user} onClose={() => setEditListing(null)} onSaved={saved => { setListings(current => current.map(item => item.id === saved.id ? saved : item)); setEditListing(null); }} />}
      {cashListing && <CashSaleDialog listing={cashListing} onClose={() => setCashListing(null)} onRecorded={() => { setCashListing(null); void load(); }} />}
    </main>
  );
}

function SellerOnboarding({ onCreated }: { onCreated: (seller: SellerProfile) => void }) {
  const [displayName, setDisplayName] = useState("");
  const [slug, setSlug] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const seller = await createSellerProfile(displayName, slug || displayName);
      onCreated(seller);
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Unable to create seller profile.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="store-shell seller-page"><section className="seller-onboarding-card"><Store size={30} /><span className="eyebrow dark">SELL ON ONETIME LABS</span><h1>Create your seller profile</h1><p>This creates your Store workspace. OneTime Labs will approve the seller account before products become publicly visible.</p><form onSubmit={submit}><label>Seller / shop name<input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Emma's Hardware" required /></label><label>Store handle<input value={slug} onChange={e => setSlug(e.target.value)} placeholder="emmas-hardware" /><small>Used for your future seller URL.</small></label>{error && <div className="checkout-error">{error}</div>}<button type="submit" className="button primary" disabled={busy}>{busy ? "Creating..." : "Create Seller Profile"}</button></form></section></main>;
}
