import { Save, X } from "lucide-react";
import { useState, type FormEvent } from "react";
import type { User } from "@supabase/supabase-js";
import {
  updateListing,
  uploadListingImages,
  type MarketplaceListing,
} from "../../services/marketplaceApi";

type Props = {
  listing: MarketplaceListing;
  user: User;
  onClose: () => void;
  onSaved: (listing: MarketplaceListing) => void;
};

export default function ListingEditDialog({ listing, user, onClose, onSaved }: Props) {
  const [title, setTitle] = useState(listing.title);
  const [description, setDescription] = useState(listing.description);
  const [condition, setCondition] = useState(listing.condition);
  const [brand, setBrand] = useState(listing.brand ?? "");
  const [model, setModel] = useState(listing.model ?? "");
  const [sku, setSku] = useState(listing.sku ?? "");
  const [price, setPrice] = useState((listing.price_cents / 100).toFixed(2));
  const [shippingPrice, setShippingPrice] = useState((listing.shipping_price_cents / 100).toFixed(2));
  const [quantity, setQuantity] = useState(String(listing.quantity));
  const [shippingAvailable, setShippingAvailable] = useState(listing.shipping_available);
  const [pickupAvailable, setPickupAvailable] = useState(listing.local_pickup_available);
  const [cashSaleAllowed, setCashSaleAllowed] = useState(listing.cash_sale_allowed);
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const newUrls = files.length ? await uploadListingImages(files, user.id) : [];
      const saved = await updateListing(listing.id, {
        title,
        description,
        condition,
        brand,
        model,
        sku,
        priceCents: Math.round(Number(price) * 100),
        shippingPriceCents: Math.round(Number(shippingPrice || 0) * 100),
        quantity: Number(quantity),
        imageUrls: [...listing.image_urls, ...newUrls].slice(0, 8),
        shippingAvailable,
        localPickupAvailable: pickupAvailable,
        cashSaleAllowed,
      });
      onSaved(saved);
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Unable to save listing.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="marketplace-modal-backdrop" role="dialog" aria-modal="true" aria-label="Edit listing">
      <form className="marketplace-modal listing-edit-modal" onSubmit={submit}>
        <button className="marketplace-modal-close" type="button" onClick={onClose} aria-label="Close"><X size={18} /></button>
        <span className="eyebrow dark">EDIT LISTING</span>
        <h2>{listing.title}</h2>
        <div className="seller-form-grid">
          <label className="span-2">Title<input value={title} onChange={e => setTitle(e.target.value)} required /></label>
          <label>Brand<input value={brand} onChange={e => setBrand(e.target.value)} /></label>
          <label>Model / Part #<input value={model} onChange={e => setModel(e.target.value)} /></label>
          <label>Condition<select value={condition} onChange={e => setCondition(e.target.value)}><option>New</option><option>Open Box</option><option>Used - Tested</option><option>Used - Untested</option><option>For Parts</option></select></label>
          <label>Quantity<input type="number" min="0" value={quantity} onChange={e => setQuantity(e.target.value)} required /></label>
          <label>Price<input type="number" min="0.01" step="0.01" value={price} onChange={e => setPrice(e.target.value)} required /></label>
          <label>Shipping price<input type="number" min="0" step="0.01" value={shippingPrice} onChange={e => setShippingPrice(e.target.value)} /></label>
          <label>SKU / Internal note<input value={sku} onChange={e => setSku(e.target.value)} /></label>
          <label className="span-2">Description<textarea rows={4} value={description} onChange={e => setDescription(e.target.value)} /></label>
          <label className="span-2">Add more photos<input type="file" accept="image/*" multiple onChange={e => setFiles(Array.from(e.target.files ?? []).slice(0, Math.max(0, 8 - listing.image_urls.length)))} /></label>
        </div>
        <div className="seller-check-grid edit-checks">
          <label><input type="checkbox" checked={shippingAvailable} onChange={e => setShippingAvailable(e.target.checked)} /> Shipping</label>
          <label><input type="checkbox" checked={pickupAvailable} onChange={e => setPickupAvailable(e.target.checked)} /> Local pickup</label>
          <label><input type="checkbox" checked={cashSaleAllowed} onChange={e => setCashSaleAllowed(e.target.checked)} /> Sold - Cash</label>
        </div>
        {error && <div className="checkout-error">{error}</div>}
        <div className="marketplace-modal-actions"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button type="submit" className="button primary" disabled={busy}><Save size={15} /> {busy ? "Saving..." : "Save Changes"}</button></div>
      </form>
    </div>
  );
}
