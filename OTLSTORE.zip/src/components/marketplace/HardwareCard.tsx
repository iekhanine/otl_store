import { MapPin, Package, Truck } from "lucide-react";
import { NavLink } from "react-router-dom";
import { formatMoney, type MarketplaceListing } from "../../services/marketplaceApi";

type Props = { product: MarketplaceListing };

export default function HardwareCard({ product }: Props) {
  const seller = product.store_sellers?.display_name || "Approved seller";
  return (
    <article className="hardware-card">
      <NavLink to={`/hardware/${product.slug}`} className="hardware-card-image">
        {product.image_urls?.[0] ? (
          <img src={product.image_urls[0]} alt={product.title} />
        ) : (
          <div className="hardware-placeholder"><Package size={34} /><span>No photo yet</span></div>
        )}
      </NavLink>
      <div className="hardware-card-body">
        <div className="hardware-card-meta">
          <span>{product.condition}</span>
          <span>{seller}</span>
        </div>
        <NavLink to={`/hardware/${product.slug}`}><h3>{product.title}</h3></NavLink>
        <div className="hardware-card-price">{formatMoney(product.price_cents, product.currency)}</div>
        <div className="hardware-card-fulfillment">
          {product.shipping_available && <span><Truck size={14} /> Ships</span>}
          {product.local_pickup_available && <span><MapPin size={14} /> Pickup</span>}
        </div>
        <div className="hardware-card-stock">{product.quantity} available</div>
      </div>
    </article>
  );
}
